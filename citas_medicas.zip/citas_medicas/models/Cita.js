const mongoose = require('mongoose');

const citaSchema = new mongoose.Schema({
  paciente: { type: String, required: true },
  doctor: { type: String, required: true },
  fecha: { type: Date, required: true },
  motivo: { type: String, required: true }
}, {
  timestamps: true
});

module.exports = mongoose.model('Cita', citaSchema);
