const express = require('express');
const mongoose = require('mongoose');
const app = express();

mongoose.connect('mongodb://localhost:27017/citasdb')
  .then(() => console.log('Conectado a MongoDB'))
  .catch(err => console.error('Error al conectar MongoDB:', err));

app.use(express.json());
app.use('/api/citas', require('./routes/citas'));

app.listen(3000, () => {
  console.log('Servidor escuchando en http://localhost:3000');
});
