const Cita = require('../models/Cita');



exports.crearCita = async (req, res) => {
  try {
    const nuevaCita = new Cita(req.body);
    await nuevaCita.save();
    res.status(201).json(nuevaCita);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al registrar la cita', error });
  }
};


exports.obtenerCitas = async (req, res) => {
  try {
    const citas = await Cita.find().sort({ fecha: 1 });
    res.json(citas);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener las citas', error });
  }
};
